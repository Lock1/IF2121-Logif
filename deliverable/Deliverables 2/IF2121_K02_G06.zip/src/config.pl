/* ----------------- File konfigurasi ----------------- */
loadingStepDuration(0.01).
% loadingStepDuration(0.001). % DEBUG
loadingBarSize(54).
% loadingBarSize(14).
% Half frame loading bar
% Change 1/8 or 1/2 on loadingPBar

triviaList(['ayam goreng enak, kalo ditraktir',
            'tuan krab aku punya ide',
            'tuan Willy tolong berikan saya gaji',
            'jika x + 3 = 9, berapakah z?',
            'fun fact : tubes ini dikerjakan dengan cara speedrun',
            'fun fact+ : loading dan fitur utf-8 diport ulang dari tubes sebelah, salam \\u2550',
            'fun fact++ : kenapa tubes sebelah tidak boleh termios.h agar input serasa raw mode kek tubes ini :(',
            'fun fact+++ : input telah dicek game loop, jadi tidak ada cheat :)',
            'fun fact++++ : intel 14nm+++++++++++++++++ mengalahkan banyaknya + pada fun fact ini',
            'tolong bantu saya, ada pointer dan fungsional disana',
            'apakah mayonnaise termasuk instrumen?',
            'mas, pesan es teh panas satu']).
