Deliverable 2 
Kelas 2 - Kelompok 6

Jalankan program ini dengan ./play

Program ini menggunakan gprolog pada wsl, dan dicompile dengan gplc v1.4.5, 
Karena menggunakan beberapa fitur pada ANSI dan karakter Box-Drawing character Unicode,
program ini tidak dapat ditampilkan dengan baik pada terminal yang tidak mensupportnya.

Terdapat sedikit backward compatibility dengan fitur Unicode & ANSI dimatikan, namun 
belum semua tampilan diport ke ASCII only.
